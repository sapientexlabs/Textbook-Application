package com.app.textbooktakeover;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.widget.SwipeRefreshLayout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.app.external.FragmentChangeListener;
import com.app.utils.Constants;
import com.app.utils.ExchangeParsing;
import com.app.utils.GetSet;
import com.app.utils.SOAPParsing;
import com.squareup.picasso.Picasso;
import com.wang.avi.AVLoadingIndicatorView;

import org.ksoap2.serialization.SoapObject;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by hitasoft on 13/6/16.
 **/
public class FailedExchange extends Fragment implements FragmentChangeListener, SwipeRefreshLayout.OnRefreshListener {

    ListView mListView;
    LinearLayout nullLay;
    AVLoadingIndicatorView progress;
    public static ExchangeAdapter exchangeAdapter;
    SwipeRefreshLayout swipeLayout;
    public static ArrayList<HashMap<String,String>> failedAry=new ArrayList<HashMap<String,String>>();
    boolean pulldown = false, loadmore = false;
    public static String type="failed";
    public static Context context;

    public FailedExchange(){}

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.exchangefragment, container , false);

        return v;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        mListView = (ListView) getView().findViewById(R.id.listView);
        progress = (AVLoadingIndicatorView) getView().findViewById(R.id.progress);
        nullLay = (LinearLayout) getView().findViewById(R.id.nullLay);
        swipeLayout = (SwipeRefreshLayout) getView().findViewById(R.id.swipeLayout);

        context = getActivity();
        swipeLayout.setColorSchemeColors(getResources().getColor(R.color.swipeColor));
        swipeLayout.setOnRefreshListener(this);

        failedAry.clear();
        new exchanges().execute("failed");
        exchangeAdapter = new ExchangeAdapter(getActivity(),failedAry);
        mListView.setAdapter(exchangeAdapter);
    }

    @Override
    public void onCentered() {

    }

    private void swipeRefresh(){
        swipeLayout.post(new Runnable() {
            @Override
            public void run() {
                swipeLayout.setRefreshing(true);
            }
        });
    }

    /** class for get the falied exchanges **/
    class exchanges extends AsyncTask<String, Void, Void> {

        @Override
        protected Void doInBackground(String... params) {
            String SOAP_ACTION = Constants.NAMESPACE + Constants.API_MY_EXCHANGE;

            SoapObject req = new SoapObject(Constants.NAMESPACE, Constants.API_MY_EXCHANGE);
            req.addProperty(Constants.SOAP_USERNAME, Constants.SOAP_USERNAME_VALUE);
            req.addProperty(Constants.SOAP_PASSWORD, Constants.SOAP_PASSWORD_VALUE);
            req.addProperty("user_id", GetSet.getUserId());
            req.addProperty("type", params[0]);

            SOAPParsing soap = new SOAPParsing();
            final String json = soap.getJSONFromUrl(SOAP_ACTION, req);

            if (pulldown){
                failedAry.clear();
            }
            ((Activity)context).runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    ArrayList<HashMap<String,String>> temp=new ArrayList<HashMap<String,String>>();
                    ExchangeParsing parse = new ExchangeParsing(context);
                    temp.addAll(parse.parsing(json));
                    if (!failedAry.contains(temp)){
                        failedAry.addAll(temp);
                    }
                }
            });
            return null;
        }

        @Override
        protected void onPreExecute() {
            loadmore = false;
            nullLay.setVisibility(View.INVISIBLE);
            if (pulldown) {
                mListView.setVisibility(View.VISIBLE);
                progress.setVisibility(View.GONE);
            } else if (failedAry.size() > 0) {
                mListView.setVisibility(View.VISIBLE);
                progress.setVisibility(View.GONE);
                swipeRefresh();
            } else {
                mListView.setVisibility(View.INVISIBLE);
                progress.setVisibility(View.VISIBLE);
            }
        }

        @Override
        protected void onPostExecute(Void unused) {
            progress.setVisibility(View.GONE);
            if(pulldown){
                pulldown = false;
            }
            swipeLayout.setRefreshing(false);
            mListView.setVisibility(View.VISIBLE);
            exchangeAdapter.notifyDataSetChanged();
            if(type.equals("failed")){
                if(failedAry.size()==0){
                    nullLay.setVisibility(View.VISIBLE);
                }else{
                    nullLay.setVisibility(View.INVISIBLE);
                }
            }
            loadmore = true;
        }

    }
    public class ExchangeAdapter extends BaseAdapter {
        ArrayList<HashMap<String, String>> Items;
        private Context mContext;
        ViewHolder holder = null;
        public ExchangeAdapter(Context ctx,ArrayList<HashMap<String, String>> data) {
            mContext = ctx;
            Items=data;
        }
        @Override
        public int getCount() {

            return Items.size();
        }

        @Override
        public Object getItem(int position) {

            return null;
        }

        @Override
        public long getItemId(int position) {

            return position;
        }

        private class ViewHolder {
            ImageView myitemImage,exitemImage,userImage;
            TextView exitemName,myitemName,view,status,time,userName;
        }

        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {

            if (convertView == null) {
                LayoutInflater inflater = (LayoutInflater) mContext
                        .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                convertView = inflater.inflate(R.layout.exchange_list_item, parent, false);//layout
                holder = new ViewHolder();
                holder.myitemImage = (ImageView) convertView.findViewById(R.id.myitemImage);
                holder.exitemImage = (ImageView) convertView.findViewById(R.id.exitemImage);
                //	holder.exRequest = (TextView) convertView.findViewById(R.id.exRequest);
                holder.exitemName = (TextView) convertView.findViewById(R.id.exitemName);
                holder.myitemName = (TextView) convertView.findViewById(R.id.myitemName);
                holder.view = (TextView) convertView.findViewById(R.id.view);
                holder.status = (TextView) convertView.findViewById(R.id.status2);
                holder.time = (TextView) convertView.findViewById(R.id.time);
                holder.userImage = (ImageView) convertView.findViewById(R.id.userImage);
                holder.userName = (TextView) convertView.findViewById(R.id.userName);

                convertView.setTag(holder);
            } else {
                holder = (ViewHolder) convertView.getTag();
            }

            try{

                final HashMap<String, String> tempMap=Items.get(position);

                if(tempMap.get(Constants.TAG_TYPE).equals("failed") || tempMap.get(Constants.TAG_TYPE).equals("failed")){
                    holder.view.setVisibility(View.GONE);
                } else{
                    holder.view.setVisibility(View.VISIBLE);
                }

                Picasso.with(getActivity()).load(tempMap.get("e"+Constants.TAG_ITEMIMAGE)).into(holder.exitemImage);
                Picasso.with(getActivity()).load(tempMap.get("m"+Constants.TAG_ITEMIMAGE)).into(holder.myitemImage);
                Picasso.with(getActivity()).load(tempMap.get(Constants.TAG_EXCHANGERIMG)).placeholder(R.drawable.appicon).error(R.drawable.appicon).into(holder.userImage);


                holder.myitemName.setText(tempMap.get("m"+Constants.TAG_ITEM_NAME));
                holder.exitemName.setText(tempMap.get("e"+Constants.TAG_ITEM_NAME));
                holder.userName.setText(tempMap.get(Constants.TAG_EXCHANGERNAME));
                holder.time.setText(tempMap.get(Constants.TAG_EXCHANGETIME));
                holder.status.setVisibility(View.VISIBLE);
                if (tempMap.get(Constants.TAG_STATUS).equalsIgnoreCase("Failed")){
                    holder.status.setText(getString(R.string.failed));
                } else if (tempMap.get(Constants.TAG_STATUS).equalsIgnoreCase("Cancelled")){
                    holder.status.setText(getString(R.string.cancelled));
                } else if (tempMap.get(Constants.TAG_STATUS).equalsIgnoreCase("Declined")){
                    holder.status.setText(getString(R.string.declined));
                }

                holder.view.setOnClickListener(new View.OnClickListener() {

                    @Override
                    public void onClick(View v) {
                        Intent i = new Intent(getActivity(), ExchangeView.class);
                        i.putExtra("data", Items.get(position));
                        i.putExtra("position", position);
                        i.putExtra("type", tempMap.get(Constants.TAG_TYPE));
                        startActivity(i);

                    }
                });

          /*  if(tempMap.get(Constants.TAG_STATUS).equals("Success")){
            	holder.status.setBackgroundColor(getResources().getColor(R.color.midgreen));
            } else if(tempMap.get(Constants.TAG_STATUS).equals("Pending")){
            	holder.status.setBackgroundColor(getResources().getColor(R.color.grey));
            } else{
            	holder.status.setBackgroundColor(getResources().getColor(R.color.red));
            }*/


            }catch(NullPointerException e){
                e.printStackTrace();
            } catch(Exception e){
                e.printStackTrace();
            }
            return convertView;
        }

    }

    @Override
    public void onRefresh() {
        if (!pulldown && loadmore) {
            pulldown = true;
            new exchanges().execute("failed");
        } else {
            swipeLayout.setRefreshing(false);
        }
    }

}



