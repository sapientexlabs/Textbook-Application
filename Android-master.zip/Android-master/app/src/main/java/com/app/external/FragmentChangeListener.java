package com.app.external;

/**
 * Created by hitasoft on 11/7/15.
 */
public interface FragmentChangeListener {

    public void onCentered();
}
