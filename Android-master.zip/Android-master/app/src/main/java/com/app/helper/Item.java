package com.app.helper;

public class Item {

	public int Id;
	public int IconFile;
	public String name;


	public Item(int id, int iconFile, String string) {
		Id = id;
		IconFile = iconFile;
		name = string;
	}

}
