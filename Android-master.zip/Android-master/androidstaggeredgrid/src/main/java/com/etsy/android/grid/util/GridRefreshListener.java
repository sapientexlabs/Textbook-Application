package com.etsy.android.grid.util;

import android.view.View;

/**
 * Created by hitasoft on 4/2/17.
 */

public interface GridRefreshListener {

    void onGridRefresh();

}
